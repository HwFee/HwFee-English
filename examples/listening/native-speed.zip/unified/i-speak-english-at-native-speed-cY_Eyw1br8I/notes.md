# I speak English at native speed

> English with Evie · 难点表达 40 条

## Feels funny to say that  `省略主语`

- 省略了 It，口语中常见：这么说感觉怪怪的。
- #3 [0:11] Feels funny to say that at normal speed, but this is the 100,000 subscriber special.
- 用正常语速说这句话感觉怪怪的，但这是十万订阅特别视频。

## these are actually two different things  `强调表达`

- actually 强调“其实是两回事”。
- #24 [1:57] and the way I speak to a native because these are actually two different things.
- 和跟母语者说话的方式有什么区别，因为这其实是两回事。

## I've made friends with people from other countries  `现在完成时`

- 我已经跟其他国家的人成了朋友，强调结果。
- #26 [2:11] I do still change my language um even when I've made friends with people from other countries, my my English is completely different.
- 我还是会调整语言。嗯，就算我跟其他国家的人成了朋友，我的英语也完全不一样。

## leaning too much into the sarcasm  `动词搭配`

- lean into 指倾向于、倚重，这里指太爱用讽刺。
- #33 [2:45] I'll avoid using too many expressions or colloquialisms or kind of leaning too much into the sarcasm.
- 我会避免用太多表达或俗语，也不会太往讽刺那边靠。

## take the piss out of each other  `英式俚语`

- 互相打趣、取笑，英国口语常用。
- #37 [3:03] Like we like to take the piss out of each other.
- 我们喜欢互相打趣。

## the minute that you end up going into  `时间状语从句`

- the minute (that) 表示“一……就……”。
- #44 [3:38] but the minute that you end up going into like a bar or a group or like a big social event where there's lots of natives who
- 但一旦进了酒吧、一个群体或大型社交活动，那里有很多母语者，他们……

## their listening comprehension drops a lot  `主谓搭配`

- 听力理解大幅下降，drop 表示下降。
- #45 [3:45] are speaking to each other, that's actually when a lot of people find that their listening comprehension drops a lot even though they're like C ones,
- 在互相聊天，很多人就会发现自己听力理解突然掉得很厉害，哪怕他们是C1，

## a lack of cultural understanding  `名词短语`

- 缺乏文化理解，lack of 表示缺少。
- #47 [3:56] And the biggest problem there is a lack of cultural understanding.
- 最大的问题是缺乏文化理解。

## in order to necessarily like pick up on the jokes  `目的状语`

- in order to 表目的，pick up on 指听懂、领会。
- #49 [4:08] I think, in order to necessarily like pick up on the jokes,
- 才能真正领会那些玩笑，

## the UK is particularly bad for this  `形容词搭配`

- 英国在这方面尤其明显/严重，be bad for 表程度。
- #51 [4:16] And I think the UK is particularly bad for this because we're very dry, we're very sarcastic,
- 我觉得英国在这方面尤其难，因为我们很冷幽默，也很爱讽刺，

## without having like the language changed at all  `介词+分词`

- without + 宾语 + 过去分词，表示语言完全没被简化。
- #56 [4:47] to each other, particularly in these like small talky, getting to know each other contexts without having like the language changed at all.
- 互相说话的机会，尤其是在那种闲聊、互相认识的场景里，而且语言完全没有被简化。

## Once you're comfortable with that  `时间状语从句`

- once 引导时间状语从句：一旦你习惯了。
- #64 [5:20] Once you're comfortable with that, then start watching comedies because that will give you like the kind of cultural understanding to if you can get the joke,
- 等你看习惯了，再开始看喜剧，因为那会给你文化理解——如果你能get到笑点，

## I am of the opinion that  `固定表达`

- 我认为，比 I think 更正式。
- #75 [6:13] You need that sort of content, but I am of the opinion that if you want amazing English or to learn any language,
- 你需要那种内容，但我认为，如果你想拥有很棒的英语，或者学好任何语言，

## whatever you would normally watch  `名词性从句`

- whatever 引导宾语从句：你平时会看的任何东西。
- #77 [6:24] If you need to be every single morning watching whatever you would normally watch in Spanish or Korean or Portuguese, you need to be watching that in English.
- 如果你每天早上都要看你平时用西班牙语、韩语或葡萄牙语看的东西，那你需要用英语去看。

## as soon as you start like replacing  `时间状语从句`

- as soon as 表示“一……就……”。
- #78 [6:38] And as soon as you start like replacing all of your habits with habits in English, your fluency is going to go through the roof.
- 一旦你开始把习惯都换成英语习惯，你的流利度会突飞猛进。

## your brain needs to be kind of immersed  `形容词/被动`

- be immersed 表示沉浸其中，kind of 是口语弱化词。
- #79 [6:46] Like because it your brain needs to be kind of immersed.
- 因为你的大脑需要沉浸。

## native content that's accessible  `定语从句`

- that 引导定语从句修饰 content：可理解的母语内容。
- #88 [7:22] I'm I'm more trying to make native content that's accessible, basically.
- 我更多是在做“让母语内容变得可理解”，基本上是这样。

## I don't know if I can pull them off  `宾语从句`

- pull off 指成功做成某事，if 引导宾语从句。
- #93 [7:44] I'll keep them quiet for now because I don't know if I can pull them off, but Um I just really wanted to say thanks to you guys.
- 现在先不说，因为我不知道能不能做成，但嗯，我真的很想谢谢你们。

## a little bit better than the last  `比较结构`

- 比上一条好一点，a little bit 修饰比较级。
- #97 [8:02] I try and make every video a little bit better than the last and I I hope you can see that
- 我努力让每个视频都比上一个好一点，希望你们能看出来，

## It really means a lot to me  `固定表达`

- 这对我意义重大，用于表达感谢。
- #100 [8:14] It It really means a lot to me and um you know, just thanks so much for watching and for subscribing and for getting me to 100,000 subscribers.
- 这对我意义重大。嗯，真的非常感谢观看、订阅，把我送到十万订阅。

## native speed  `名词短语`

- 母语者的正常语速，native 指母语的。
- #2 [0:02] My name is Evie and this is a video at native speed English to help you practice your listening comprehension.
- 我叫Evie，这是一期用母语语速说的英语视频，帮你练习听力理解。

## subscriber special  `名词短语`

- 为订阅者做的特别节目，special 作名词指特别篇。
- #3 [0:11] Feels funny to say that at normal speed, but this is the 100,000 subscriber special.
- 用正常语速说这句话感觉怪怪的，但这是十万订阅特别视频。

## mix it up  `短语动词`

- 换换花样、做点不一样的。
- #4 [0:17] So, I thought maybe I should mix it up a little bit.
- 所以我想，也许该换个花样。

## how much you can understand  `宾语从句`

- 你能听懂多少，how much 引导宾语从句。
- #6 [0:26] I would love to know how much you can understand.
- 我很想知道你们能听懂多少。

## about 1,000 away  `数量表达`

- 还差大约一千，away 表示距离目标的数量。
- #9 [0:43] Um I'm about 1,000 away right now, but I wanted this video to be filmed and ready so I could upload it.
- 嗯，现在还差一千左右，但我想先把视频拍好备着，好随时上传。

## running my channel  `动词短语`

- 经营我的频道，run a channel 指运营频道。
- #11 [0:56] Um I've been running my channel now for about 4 months.
- 嗯，我这个频道做了大概四个月。

## the exact beach  `名词短语`

- 正是那片海滩，exact 表示“一模一样的”。
- #13 [1:03] And this is the exact beach that I filmed in my very very first vlog.
- 这就是我拍第一支vlog的那片海滩。

## retaking the video  `动词短语`

- 重拍视频，retake 指重新拍摄。
- #16 [1:12] I was like my voice was shaking and I had to keep retaking the video cuz I was so scared.
- 我声音都在抖，怕得一直重拍。

## come across  `短语动词`

- 给人某种印象，这里指“看起来更放松”。
- #18 [1:20] So, feels pretty cool to to be here now and hopefully I come across a little bit more relaxed.
- 现在坐在这儿感觉挺酷的，希望我看起来稍微放松了一点。

## advanced English learner  `名词短语`

- 高阶英语学习者，advanced 指高级的。
- #20 [1:32] One, I wanted to speak about the difference between advanced like how I speak to an advanced English learner and how I speak to a native.
- 第一，我想聊聊区别——我跟高阶英语学习者说话的方式，和跟母语者说话的方式有什么不同。

## fluent  `形容词`

- 流利的、流畅的。
- #25 [2:01] Um when I speak to an advanced English speaker like even somebody who's like C1 C2, they're basically fluent, they can work in English.
- 嗯，我跟高阶英语使用者说话时，哪怕是C1、C2水平、基本流利、能用英语工作的人，

## the main difference  `名词短语`

- 主要区别，main 指最重要的。
- #30 [2:29] And the main difference is not necessarily the speed, but like the words that I choose and the words that I use.
- 主要区别不一定是语速，而是我选的词、我用的词。

## heavy slang  `名词短语`

- 很重的俚语，heavy 表示程度强。
- #31 [2:37] So, when I speak to an advanced English speaker I will avoid like really heavy slang.
- 所以跟高阶英语使用者说话时，我会避免用很重的俚语。

## colloquialisms  `名词`

- 俗语、口语化表达，比 slang 更书面。
- #33 [2:45] I'll avoid using too many expressions or colloquialisms or kind of leaning too much into the sarcasm.
- 我会避免用太多表达或俗语，也不会太往讽刺那边靠。

## specific words  `名词短语`

- 具体的、特定的词汇。
- #39 [3:11] because I'm speaking faster and I'm using more specific words and phrases in here as well.
- 因为我语速更快，还用了更具体的词和短语。

## cultural understanding  `名词短语`

- 对文化的理解，跨文化交际中的关键能力。
- #47 [3:56] And the biggest problem there is a lack of cultural understanding.
- 最大的问题是缺乏文化理解。

## reality TV  `名词短语`

- 真人秀节目，reality television 的口语缩写。
- #53 [4:28] maybe my videos are too slow for you or you want something more challenging, you need to watch reality TV.
- 也许我的视频对你来说太慢了，或者你想要更有挑战的，那你需要看真人秀。

## you already know the drill  `口语表达`

- 规矩你都懂、流程你熟悉，drill 指固定做法。
- #59 [5:03] No subtitles, you already know the drill.
- 别开字幕，规矩你们都懂。

## after a day of work  `介词短语`

- 上了一天班之后，after 引导时间状语。
- #82 [6:53] So, you know, I wanted to make content that you would actually want to sit and watch after a day of work.
- 所以我想做那种你下班后真的愿意坐下来看的内容。

## go through the roof  `习语`

- （数量、水平）暴涨、飙升。
- #78 [6:38] And as soon as you start like replacing all of your habits with habits in English, your fluency is going to go through the roof.
- 一旦你开始把习惯都换成英语习惯，你的流利度会突飞猛进。
